local lib = {}

function lib:init()
    
end

return lib